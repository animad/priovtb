<?php

	class tools{
		
		function tools(){
			
		}
		
	}

?>