<?die;?>
uid:ff527a05550a2a2a45cfd0cc2912465c
on:0
login:tester
passw:f5d1278e8109edd94e1e4197e04873b9
status:user
mallow:755f9b12608dbcfcd769e6bd26b95319 6dab09ed8eb6e0b9cb976844da724673 fc1a568a66050fba6b7d3c8d205f76c8 b71dfe1ca1efbaf89a6b4b6eaaea59a3 9606ce826dc7e98ac7a3d8218421e8ba 635c311f486e8677f4a8de4e7516a450 9a384256273775a8c639a1248fe01554 12b7d24ff3821892bf7bf3c58a9ad660 caf0fa6d76e4fd900db71656f6d23b68
name:
surname:
nickname:
showname:tester
email:
site_url:
ftp_host:
ftp_ssl:
ftp_user:
ftp_pass:
ftp_rdir: