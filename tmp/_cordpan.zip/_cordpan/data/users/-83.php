<?die;?>
uid:99c5c86434166ed54e962ea04aef9923
on:0
login:stpuser1
passw:fcc218c34f12736dd542d08f54079774
status:user
mallow:b71dfe1ca1efbaf89a6b4b6eaaea59a3
name:
surname:
nickname:
showname:���������� ���
email:
site_url:
ftp_host:
ftp_ssl:
ftp_user:
ftp_pass:
ftp_rdir: