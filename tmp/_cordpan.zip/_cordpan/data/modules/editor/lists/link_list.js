var tinyMCELinkList = new Array(
	["title_about.gif","http://animad.ru"]
);